## Setup

Start with your `cs224r` conda environment, or create a new conda environment based on the instructions provided to you in homework 1.

Then run the following commands when you're under the `hw3/` folder.

```
conda activate cs224r
sudo apt-get install swig
pip install -r requirements.txt
pip install -e .
```

## TODOs

The TODOs and descriptions for code that needs to be implemented has been provided in the homework PDF.